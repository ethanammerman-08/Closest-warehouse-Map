package application;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.io.File;
/**
 * The FullfilmentCenters class that holds the adjacency matrix and array list
 */
public class FulfillmentCenters {
	private final List<Center> centers = new ArrayList<>();
	private double[][] adjacencyMatrix;
/**
 * Gets the list of centers
 * @return the centers
 */
	public List<Center> getCenters() {
	    return centers;
	}
	/**
	 * Reads in the file (CenterInformation.txt) to read trhough the information also reads through the adjacency matrix
	 * @param fileName
	 */
	public void readFile(String fileName) {
		try (Scanner sc = new Scanner(new File("CentersInformation.txt"))) {
			int numCenters = Integer.parseInt(sc.nextLine().trim());
			adjacencyMatrix = new double[numCenters][numCenters];

			for (int i = 0; i < numCenters; i++) {
				String[] parts = sc.nextLine().trim().split("\\s+");
				String name = parts[0];
				int x = Integer.parseInt(parts[1]);
				int y = Integer.parseInt(parts[2]);
				double radius = Double.parseDouble(parts[3]);

				Center center = new Center(name, x, y, radius);
				centers.add(center);
			}
			//Read adjacency matrix
			for (int i = 0; i < numCenters; i++) {
				String[] row = sc.nextLine().trim().split("\\s+");

				for (int j = 0; j < numCenters; j++) {
					int connection = Integer.parseInt(row[j]);

					if (connection == -1) {
						adjacencyMatrix[i][j] = -1.0;  
					} else if (i == j) {
						adjacencyMatrix[i][j] = 0.0;   
					} else {

						Center c1 = centers.get(i);
						Center c2 = centers.get(j);
						int loc1 = c1.getxCoord();
						int loc2 = c2.getyCoord();

						double distance = Math.sqrt(Math.pow(loc1 - loc2, 2) + Math.pow(loc1 - loc2, 2));
						adjacencyMatrix[i][j] = distance;
					}
				}
			}

		} catch (Exception e) {
			System.out.println("Error reading file: " + e.getMessage());
		}
	}

/**
 * Creates a toString to print out the file
 */
	@Override
	public String toString() {
		String result = "";

		for (Center c : centers) {
			result += c.toString() + "\n";
		}

		result += "Adjacency Matrix:\n\t";
		for (Center c : centers) {
			result += c.getCenterName() + "\t";
		}
		result += "\n";

		for (int i = 0; i < adjacencyMatrix.length; i++) {
			result += centers.get(i).getCenterName() + "\t";
			for (int j = 0; j < adjacencyMatrix[i].length; j++) {
				result += String.format("%.2f\t", adjacencyMatrix[i][j]);
			}
			result += "\n";
		}

		return result;
	}
	/**
	 * CAlculates the area
	 * @return area
	 */
	public double calculateArea() {
		double totalArea = 0;
		for (Center c : centers) {
			totalArea += c.getArea();
		}
		return totalArea;
	}
/**
 * get the information for the centers
 * @param name 
 * @return centers
 */
	public Center getInformation(String n) {
		for (Center c : centers) {
			if (c.getCenterName().equalsIgnoreCase(n)) {
				return c;
			}
		}
		return null;
	}
/**
 * method to get the closest centers
 * @param name
 * @return
 */
	public List<String> getClosestCenters(String n) {
		List<String> result = new ArrayList<>();
		int index = getCenterName(n);
		if (index == -1) return result;

		for (int j = 0; j < adjacencyMatrix[index].length; j++) {
			if (adjacencyMatrix[index][j] > 0) {
				result.add(centers.get(j).getCenterName() + " (" + String.format("%.2f", adjacencyMatrix[index][j]) + ")");
			}
		}
		return result;
	}
	/**
	 * distances to certain centers
	 * @param centerName name of teh center
	 * @returnthe Distances to 
	 */
	public List<String> distancesTo(String centerName) {
		int source = getCenterName(centerName);
		int n = centers.size();
		double[] dist = new double[n];
		boolean[] visited = new boolean[n];

		Arrays.fill(dist, Double.MAX_VALUE);
		dist[source] = 0;

		for (int i = 0; i < n; i++) {
			int u = getMinDistanceIndex(dist, visited);
			visited[u] = true;

			for (int v = 0; v < n; v++) {
				if (!visited[v] && adjacencyMatrix[u][v] > 0) {
					double newDist = dist[u] + adjacencyMatrix[u][v];
					if (newDist < dist[v]) {
						dist[v] = newDist;
					}
				}
			}
		}

		List<String> result = new ArrayList<>();
		for (int i = 0; i < n; i++) {
			if (i != source && dist[i] != Double.MAX_VALUE) {
				result.add(centers.get(i).getCenterName() + ": " + String.format("%.2f", dist[i]));
			}
		}
		return result;
	}
/**
 * Returns the Center Name 
 * @param name
 * @return
 */
	private int getCenterName(String name) {
		for (int i = 0; i < centers.size(); i++) {
			if (centers.get(i).getCenterName().equalsIgnoreCase(name)) {
				return i;
			}
		}
		return -1;
	}
/**
 * The minimum distance index
 * @param dist distance in the array
 * @param visited lets you know if you have already been to that index
 * @return the index
 */
	private int getMinDistanceIndex(double[] dist, boolean[] visited) {
		double min = Double.MAX_VALUE;
		int index = -1;

		for (int i = 0; i < dist.length; i++) {
			if (!visited[i] && dist[i] < min) {
				min = dist[i];
				index = i;
			}
		}
		return index;
	}

}

