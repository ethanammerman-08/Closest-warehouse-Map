package application;

/**
 * Center class that holds teh coordinates for the centers
 */
public class Center {
	private String CenterName;
	private int xCoord;
	private int yCoord;
	private double radius;

/**
 * Constructor and setters and getters for the Center class
 * @param CenterName Name of the center
 * @param xCoord x coordinate
 * @param yCoord y coordinate
 * @param radius radius
 */
	public Center(String CenterName, int xCoord, int yCoord, double radius) {
		this.CenterName = CenterName;
		this.xCoord = xCoord;
		this.yCoord = yCoord;
		this.radius = radius;
	}


	public String getCenterName() {
		return CenterName;
	}





	public int getxCoord() {
		return xCoord;
	}





	public int getyCoord() {
		return yCoord;
	}



	public double getRadius() {
		return radius;
	}




/**
 * gets the area
 * @return area
 */
	public double getArea() {
		return Math.PI * radius * radius;
	}
/**
 * Finds the distanceTo method
 * @param other
 * @return
 */
	public double distanceTo(Center other) {
		return Math.hypot(this.xCoord - other.xCoord, this.yCoord - other.yCoord);
	}
	@Override
	/**
	 * ToString to print out the area name and location
	 */
	public String toString() {
		return "Name: " + CenterName + ", Location: [" + xCoord + "," + yCoord + "], Area: " + String.format("%.2f", getArea());
	}
}


