package application;

import java.io.FileInputStream;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
/**
 * MAin class that runs the entire GUI
 */
public class Main extends Application implements EventHandler<MouseEvent> {
	private int ratio;
	private InformationPanel infoPanel;
	private Center selectedCity;
	private FulfillmentCenters network;

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	/**
	 * Starts the GUI and generates the GUI design
	 */
	public void start(Stage primaryStage) {
		try {
			network = new FulfillmentCenters();
			network.readFile("CentersInformation.txt"); // Read the centers

			BorderPane root = new BorderPane();
			
			// Top title
			Label title = new Label("Ethan Ammerman - Advanced Data Structures");
			root.setTop(title);
			
			// Left: Map Image
			FileInputStream inputFile = new FileInputStream("CentersGraph.jpg");
			Image graphImage = new Image(inputFile, 550, 650, true, false);
			ImageView graphView = new ImageView(graphImage);
			ratio = 45;
			graphView.setOnMousePressed(this);

			// Right: Buttons + TextArea
			infoPanel = new InformationPanel(this);

			HBox layout = new HBox();
			layout.getChildren().addAll(graphView, infoPanel);
			root.setCenter(layout);

			Scene scene = new Scene(root, 900, 700); // Bigger width for buttons
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setTitle("Fulfillment Centers Map");
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
/**
 * Handles the clicks and what will be printed in the terminal
 */
	@Override
	public void handle(MouseEvent event) {
		double xCoordinate = event.getX();
		double yCoordinate = event.getY();
		xCoordinate = xCoordinate / ratio;
		yCoordinate = yCoordinate / ratio - 2;

		System.out.println("Scaled values: " + xCoordinate + " " + yCoordinate);

		selectedCity = findClosestCity(xCoordinate, yCoordinate);
		if (selectedCity != null) {
			infoPanel.updateText(network.getInformation(selectedCity.getCenterName()).toString());
		}
	}
/**
 * Finds the closest centers to where user clicks
 * @param x this is the x coordinate
 * @param y this is the y coordinate
 * @return
 */
	private Center findClosestCity(double x, double y) {
		Center closest = null;
		double minDistance = Double.MAX_VALUE;
		for (Center c : network.getCenters()) {
			double distance = Math.hypot(x - c.getxCoord(), y - c.getyCoord());
			if (distance < minDistance) {
				minDistance = distance;
				closest = c;
			}
		}
		return closest;
	}

	public Center getSelectedCity() {
		return selectedCity;
	}

	public FulfillmentCenters getNetwork() {
		return network;
	}
}
