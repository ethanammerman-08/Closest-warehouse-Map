package application;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
/***
 * Information Panel class to run the GUI and buttons
 */
public class InformationPanel extends VBox implements EventHandler<ActionEvent> {

	private Button closestCenterB;
	private Button computeDistanceB;
	private Button calculateAreaB;
	private TextArea textArea;
	private Main mainGUI;
/**
 * InformationPanel contsructor and creation of different parts of the GUI
 * @param newMainGUI
 */
	public InformationPanel(Main newMainGUI) {
		mainGUI = newMainGUI;

		closestCenterB = new Button("Find Closest Center");
		computeDistanceB = new Button("Calculate the Distances");
		calculateAreaB = new Button("Calculate Total Area");
		textArea = new TextArea();

		this.getChildren().addAll(closestCenterB, computeDistanceB, calculateAreaB, textArea);

		closestCenterB.setOnAction(this);
		computeDistanceB.setOnAction(this);
		calculateAreaB.setOnAction(this);

		textArea.setPrefHeight(600);
		textArea.setWrapText(true);
	}

	@Override
	/**
	 * HAndles the clicks and actions with the GUI
	 */
	public void handle(ActionEvent event) {
		if (event.getSource() == closestCenterB) {
			Center selected = mainGUI.getSelectedCity();
			if (selected != null) {
				StringBuilder sb = new StringBuilder();
				for (String s : mainGUI.getNetwork().getClosestCenters(selected.getCenterName())) {
					sb.append(s).append("\n");
				}
				textArea.setText(sb.toString());
			} else {
				textArea.setText("No center selected.");
			}
		} else if (event.getSource() == computeDistanceB) {
			Center selected = mainGUI.getSelectedCity();
			if (selected != null) {
				StringBuilder sb = new StringBuilder();
				for (String s : mainGUI.getNetwork().distancesTo(selected.getCenterName())) {
					sb.append(s).append("\n");
				}
				textArea.setText(sb.toString());
			} else {
				textArea.setText("No center selected.");
			}
		} else if (event.getSource() == calculateAreaB) {
			double area = mainGUI.getNetwork().calculateArea();
			textArea.setText("Total Area: " + String.format("%.2f", area));
		}
	}

	public void updateText(String info) {
		textArea.setText(info);
	}
}